# SQL_FORMAT

A simple way to format you single line SQL query into a multi-line SQL Query


