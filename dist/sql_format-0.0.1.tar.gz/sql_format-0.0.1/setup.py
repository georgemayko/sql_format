# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sql_format']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.27.1,<3.0.0', 'typer[all]>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['sql_format = sql_format.main:app']}

setup_kwargs = {
    'name': 'sql-format',
    'version': '0.0.1',
    'description': 'A simple command to format a single line SQL query into a multi-line SQL query',
    'long_description': '# SQL_FORMAT\n\nA simple way to format you single line SQL query into a multi-line SQL Query\n\n\n',
    'author': 'George Mayko',
    'author_email': 'mayko.george@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
